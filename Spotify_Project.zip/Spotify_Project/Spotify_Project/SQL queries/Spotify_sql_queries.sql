create database Spotify_Album;
use Spotify_Album; 

Select * From best_selling_albums
limit 5;
select year, sum(Sales_Millions) AS Sales
from best_selling_albums
group by year
order by Sales Desc
limit 10;

select Country, sum(Sales_Millions) AS Country_sales
from best_selling_albums
group by Country
order by Country_sales Desc;

select Genre, sum(Sales_Millions) AS Genre_sales
from best_selling_albums
group by Genre
order by Genre_sales Desc;

select Decade, sum(Sales_Millions) AS Decade_sales
from best_selling_albums
group by Decade
order by decade_sales Desc;

select Artist, sum(Sales_Millions) AS Artist_sales
From best_selling_albums
group by Artist
order by Artist_sales Desc
limit 5;

select * from best_selling_albums
where Album IS NULL;

select Sales_Millions from best_selling_albums
order by Sales_Millions Desc;

select Sales_Millions, 
CASE
WHEN Sales_Millions < 30 THEN 'Low'
when Sales_Millions between 30 AND 40 THEN 'Medium'
ELSE 'High'
END AS Sales_category
From best_selling_albums;

Create VIEW Selling_album AS 
select Artist, sum(Sales_Millions) AS Total_sales
from best_selling_albums
group by Artist;

select * from best_selling_albums;
