📊 Best Selling Albums – **SQL Data Analysis Project**



📁 **Project Overview**



This project focuses on analyzing the Best Selling Albums dataset using SQL to extract meaningful insights from raw data.

The objective of this project is to perform data exploration, aggregation, segmentation, and trend analysis to understand global music sales performance across different dimensions such as time, geography, genre, and artist.



This project is designed as a portfolio-level SQL analytics project for aspiring Data Analysts and Business Analysts.



**📊 Dataset Description**



The dataset contains structured information about best-selling music albums, including:



**•** Artist



**•** Album



**•** Year



**•** Decade



**•** Country



**•** Genre



**•** Sales\_Millions (Album sales in millions)



**🛠 Tools \& Technologies Used**



SQL **(MySQL / PostgreSQL compatible queries)**



Database Management System (DBMS)



GitHub (Project hosting \& version control)



Power BI / Tableau (for future dashboard integration)



📌 SQL Concepts Used



**•** SELECT



**•** WHERE



**•** GROUP BY



**•** ORDER BY



**•** LIMIT



**•** AGGREGATE FUNCTIONS (SUM)



**•** CASE WHEN (Conditional Logic)



**•** ALIASES (AS)



**•** VIEWS (CREATE VIEW)



**•** DATA FILTERING



**•** DATA SEGMENTATION



**•** DATA AGGREGATION



📈 Analysis Performed

**1. Data Exploration**



Viewing sample records using SELECT \*



Understanding table structure and columns



Checking for missing values (IS NULL)



**2. Time-Based Analysis**



Year-wise sales analysis



Decade-wise sales trends



Identification of peak sales periods



**3. Geographical Analysis**



Country-wise total album sales



Identification of top-performing music markets



**4. Category Analysis**



Genre-wise sales performance



Sales classification using CASE statements (Low / Medium / High)



**5. Artist Performance Analysis**



Top artists by total sales



Artist-wise aggregated performance



Ranking analysis



**6. Data Modeling**



Creation of SQL Views for reusable summarized data



Optimized queries for reporting and dashboards



**📊 Insights Summary**



Identified top-performing years and decades in music sales history



Discovered countries with highest album sales contribution



Analyzed most profitable genres in the music industry



Ranked top artists based on total sales



Classified albums into Low, Medium, and High sales categories



Built structured datasets for business reporting and visualization



**🔚 Conclusion**



This project demonstrates a complete end-to-end SQL data analytics workflow, transforming raw music sales data into actionable insights.

It reflects strong understanding of data analysis fundamentals, SQL querying techniques, and analytical thinking.

